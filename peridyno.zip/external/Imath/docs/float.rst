Floating Point Representation
#############################

.. doxygenfile:: half.h
   :sections: detaileddescription 

