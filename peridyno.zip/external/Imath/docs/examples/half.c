#include <Imath/half.h>

void
half_example()
{
    float f = 3.5f;
  
    half h = imath_float_to_half (f)

    float hh = imath_half_to_float (h)
}

